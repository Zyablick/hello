$(document).ready(function() {
// alert("Careful, you will get deep into the ocean");
// alert("Are you sure you want to continue?");
// console.log( "ready!" );

// alert("Okay, we warned you...");
$("#part1").draggable();
$("#part2").draggable();
$("#part3").draggable();
$("#part4").draggable();
});

const synth = window.speechSynthesis;

document.querySelector("#button").onclick = () => {
  console.log("button clicked");
  speak("sorry there is nothing there");
};
document.querySelector("#part1").onclick = () => {
  console.log("part1 clicked");
  speak("sorry there is nothing there");
};



const speak = (text) => {
//to check if speaking
  if (synth.speaking) {
    console.error("it's speaking");
    return;
  }

  let utterThis = new SpeechSynthesisUtterance (text);
  utterThis.lang = "ru-RU";
  utterThis.pitch = 0.1;
  utterThis.rate = 0.3;

  synth.speak(utterThis);
};
